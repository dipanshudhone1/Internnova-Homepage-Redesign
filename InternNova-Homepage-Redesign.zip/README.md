# InternNova Homepage Redesign
Original responsive homepage redesign for the Web Development internship task.

## Files
- index.html
- style.css
- script.js

## Sections
Navigation, Hero, About, Programs, Domains, Why Us, Learning Journey, Workshops, Testimonials, Statistics, FAQ, CTA and Footer.

## Run
Open `index.html` in a browser.

## GitHub Pages
Create a public repository, upload all 3 files, then Settings → Pages → Deploy from branch → main → /root → Save.
